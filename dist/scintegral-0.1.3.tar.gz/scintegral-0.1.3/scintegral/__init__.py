"""
	scIntegral
	~~~~~~~~~~

	:copyright: (c) 2020 by Hanbin Lee
	:license: GPL version 2.
"""

__version__ = '0.1.2'
